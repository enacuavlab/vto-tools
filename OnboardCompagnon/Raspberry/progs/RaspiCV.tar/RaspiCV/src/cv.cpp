#include "cv.h"
#include <opencv2/opencv.hpp>
#include <pthread.h>

#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

using namespace cv;
using namespace std;

/*****************************************************************************/
#define SAD_LIMIT 2000
#define streamOutGstStr "appsrc ! shmsink socket-path=/tmp/camera3 wait-for-connection=false async=false sync=false"

/*****************************************************************************/
#define IMUPIPE "/tmp/fromimu"
float msgpipe_g[3];
int imufd;
Point pcenter(320,240);
float torad = CV_PI / 180.0;

struct motion_elt_t {
  int8_t x;
  int8_t y;
  uint16_t sad;
};
static motion_elt_t *motionIn;
static Mat1b gray;
static int width,height,fps; 

static pthread_mutex_t imv_mutex;
static bool imv_ready=false; 

static pthread_t img_thread;
static pthread_mutex_t img_mutex;
static pthread_cond_t img_condv;
static bool img_ready=false; 

static bool init_ready=false; 

/*****************************************************************************/
static void * drawAxes_threadImuProg(void *arg) {
  float msgpipe_l[3];
  int msgsize = sizeof(msgpipe_g);
  while(true) {
    if (msgsize==read(imufd,&msgpipe_l,msgsize)) {
      memcpy(&msgpipe_g, &msgpipe_l, msgsize); 
    } 
  }
}

static void drawAxes_init()
{
  mkfifo(IMUPIPE, 0666); 
  imufd = open(IMUPIPE, O_RDWR);

  pthread_t threadImu;
  pthread_create(&threadImu, NULL, &drawAxes_threadImuProg, NULL);
}

struct quaternion_t
{
  float w, x, y, z;
};

static void drawAxes(Mat3b *img) 
{
  float msgpipe_l[3];
  memcpy(&msgpipe_l, &msgpipe_g, sizeof(msgpipe_g));

  float roll  =  torad*msgpipe_l[0];   // roll_phy(x)
  float pitch = -torad*msgpipe_l[1]; // pitch_theta(y)
  float yaw   = -torad*msgpipe_l[2];   // yaw_psi(z)

  float cy = cos(roll * 0.5);
  float sy = sin(roll * 0.5);
  float cp = cos(yaw * 0.5);
  float sp = sin(yaw * 0.5);
  float cr = cos(pitch * 0.5);
  float sr = sin(pitch * 0.5);

  quaternion_t q;          // quaternion from euler
  q.w = cr * cp * cy + sr * sp * sy;
  q.x = sr * cp * cy - cr * sp * sy;
  q.y = cr * sp * cy + sr * cp * sy;
  q.z = cr * cp * sy - sr * sp * cy;

  array<Point3i,4> pts = {Point3i{0,0,0},Point3i{100,0,0},Point3i{0,100,0},Point3i{0,0,100}};
  array<Point3f,4> out;
  for (int i=0;i<4;i++) {  // rotation matrix from quaternion
    out[i].x=(1-2*q.y*q.y-2*q.z*q.z)*pts[i].x+(2*q.x*q.y-2*q.z*q.w)*pts[i].y+(2*q.x*q.z+2*q.y*q.w)*pts[i].z;
    out[i].y=(2*q.x*q.y+2*q.z*q.w)*pts[i].x+(1-2*q.x*q.x-2*q.z*q.z)*pts[i].y+(2*q.y*q.z-2*q.x*q.w)*pts[i].z;
    out[i].z=(2*q.x*q.z-2*q.y*q.w)*pts[i].x+(2*q.y*q.z+2*q.x*q.w)*pts[i].y+(1-2*q.x*q.x-2*q.y*q.y)*pts[i].z;
  }

  Point loc=pcenter;
  array<Point,4> imgPts;   // 3D to 2D projection
  for (int i=0;i<4;i++)
    imgPts[i]={(int)(loc.x-out[i].x+0.5*out[i].z),(int)(loc.y-out[i].y-0.5*out[i].z)};

  line(*img, imgPts[0], imgPts[3], Scalar(0,0,255), 3); // red
  line(*img, imgPts[0], imgPts[1], Scalar(0,255,0), 3); // green
  line(*img, imgPts[0], imgPts[2], Scalar(255,0,0), 3); // blue
  circle(*img, pcenter, 5, Scalar(0,0,0), -1);
}

/*****************************************************************************/
static void *process_thread(void *ptr)
{
  VideoWriter strOut = VideoWriter(streamOutGstStr,0,fps/1,Size(width,height),true); 
  Mat3b grayBGR;
  Mat colormap;
  int32_t sum_x,sum_y;

  int mbx = width/16;
  int mby = height/16;
  int mbxy = (8 * mbx * mby);
  unsigned int motionSize = ((mbx+1)*mby) * sizeof(struct motion_elt_t); 
  motion_elt_t *motionOut = new motion_elt_t[(mbx+1)*mby];

  char buff[20];int lg;


  while (true) {
    pthread_mutex_lock(&img_mutex);
    while (!img_ready) pthread_cond_wait(&img_condv, &img_mutex);
    cvtColor(gray, grayBGR, COLOR_GRAY2BGR);
    applyColorMap(grayBGR, colormap, COLORMAP_JET);

    img_ready=false;
    pthread_mutex_unlock(&img_mutex); 

    if(imv_ready) { 
      pthread_mutex_lock(&imv_mutex);
      memcpy(motionOut ,motionIn, motionSize);
      imv_ready=false;
      pthread_mutex_unlock(&imv_mutex);
    } 

    sum_x=0;sum_y=0;
    for (int j=0;j<mby;j++) {
      for (int i=0;i<mbx;i++) { 
        motion_elt_t *vec = motionOut + (i+(mbx+1)*j); 
        if (vec->x == 0 && vec->y == 0) continue;
        if (vec->sad > SAD_LIMIT) continue;
	int x = i*16 + 8;
	int y = j*16 + 8;
	float intensity = vec->sad;
	intensity = round(255 * intensity / SAD_LIMIT);
	if (intensity > 255) intensity = 255;
	uint8_t *ptr = colormap.ptr<uchar>(0);
	uint8_t idx = 3*(uint8_t)intensity;
	arrowedLine(grayBGR, Point(x+vec->x, y+vec->y),
			   Point(x, y),
			   Scalar(ptr[idx], ptr[idx+1], ptr[idx+2]));

	sum_x += (intensity * vec->x);
	sum_y += (intensity * vec->y);
      }
    }

    sum_x = (sum_x/mbxy);
    sum_y = (sum_y/mbxy);
    arrowedLine(grayBGR, Point(320,240),Point(320+sum_x,240+sum_y),Scalar(0,255,0),5);

    drawAxes(&grayBGR);

    strOut.write(grayBGR);
  }
  return((void *)0);
}
 
/*****************************************************************************/
void cv_init(int w, int h, int f, int fmt)
{
//  freopen( "/tmp/error.txt", "w", stderr );
//  cerr << length << endl;
//    fd << static_cast<int32_t>(sum_x) << endl;

  drawAxes_init();

  width=w;height=h;fps=f;

  gray = Mat(height, width, CV_8UC1);
  motionIn = new motion_elt_t[((width/16)+1) * (height/16)]; 

  pthread_mutex_init(&imv_mutex, NULL);

  pthread_mutex_init(&img_mutex, NULL);
  pthread_cond_init(&img_condv, NULL);

  pthread_create(&img_thread, NULL, process_thread, (void *)0);

  init_ready=true;
}

/*****************************************************************************/
void cv_process_img(uint8_t *p_buffer, int length, int64_t timestamp)
{
  if (init_ready) {
    pthread_mutex_lock(&img_mutex);
    memcpy(gray.data, p_buffer, length);		
    img_ready=true;
    pthread_cond_signal(&img_condv);
    pthread_mutex_unlock(&img_mutex);
  }
}

/*****************************************************************************/
void cv_process_imv(uint8_t *p_buffer, int length, int64_t timestamp)
{
  if (init_ready) {
    pthread_mutex_lock(&imv_mutex);
    memcpy(motionIn ,p_buffer, length);
    imv_ready=true;
    pthread_mutex_unlock(&imv_mutex);
  }
}

/*****************************************************************************/
void cv_close(void)
{
}

