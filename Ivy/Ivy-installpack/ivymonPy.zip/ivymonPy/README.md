
IvyMon is a simple Ivy software bus message viewer written in python3 and Qt

to install it:
	pip3 install ivy-bus PyQt5

to run:
	python3 ivymon.py
